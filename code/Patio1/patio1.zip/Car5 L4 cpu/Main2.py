from us2 import get_distance2
from us1 import get_distance1
import time
from pyb import UART
from PID1 import *
from Edge import *
from uart import *

sensor.reset()                      # Reset and initialize the sensor.
sensor.set_pixformat(sensor.GRAYSCALE) # Set pixel format to RGB565 (or GRAYSCALE)
sensor.set_framesize(sensor.QVGA)   # Set frame size to QQVGA (160x120)
sensor.skip_frames(time = 2000)     # Wait for settings take effect.
uart = UART(3, 19200)
Robot=PID(p=1,i=0.3,d=0)

while(True):
    c=find_error()
    print(c)
    a=int(get_distance1())
    b=int(get_distance2())
    print(a)
    print(b)
    a=10
    b=10
    time.sleep_ms(10)
    uartc(c,a,b) #pass the duty cycle to left and right



